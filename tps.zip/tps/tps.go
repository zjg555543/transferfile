package main

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"math/big"
	"net/http"
	"sync"
	"tps/dusd"

	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/crypto"
	"github.com/ethereum/go-ethereum/ethclient"
	"github.com/gorilla/mux"
)

const (
	privateKeyHex       = "0x7a28a6e07f95fb5802c23279f38895a42212b8ddc886dde3168788a44085de0d"
	sepoliaRPCURL       = "https://rpc.ankr.com/eth_sepolia/578c95407e7831f0ac1ef79cacae294dc9bf8307121ca9fffaf1e556a5cca662"
	dusdContractAddress = "0x35169cCAbeb5dE1E88443FC516be7f13556Dbb41"
	tokenDecimals       = 6
)

type TransferRequest struct {
	Recipient string  `json:"recipient"`
	Amount    float64 `json:"amount"`
}

type Server struct {
	client *ethclient.Client
	mutex  sync.Mutex
}

func main() {
	// Load private key
	_, err := crypto.HexToECDSA(privateKeyHex[2:])
	if err != nil {
		log.Fatalf("Failed to load private key: %v", err)
	}

	// Create an Ethereum client
	client, err := ethclient.Dial(sepoliaRPCURL)
	if err != nil {
		log.Fatalf("Failed to connect to Sepolia network: %v", err)
	}

	// Initialize server
	server := &Server{
		client: client,
	}

	router := mux.NewRouter()
	router.HandleFunc("/transfer", server.handleTransfer).Methods("POST")
	log.Println("Server running on port 8080")
	log.Fatal(http.ListenAndServe(":8080", router))
}

func (s *Server) handleTransfer(w http.ResponseWriter, r *http.Request) {
	var req TransferRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid request body", http.StatusBadRequest)
		return
	}

	recipient := common.HexToAddress(req.Recipient)
	amount := new(big.Int).Mul(big.NewInt(int64(req.Amount*float64(tokenDecimals))), big.NewInt(1))

	s.mutex.Lock()
	defer s.mutex.Unlock()

	// Send the token transfer
	err := s.sendToken(recipient, amount)
	if err != nil {
		http.Error(w, fmt.Sprintf("Failed to transfer tokens: %v", err), http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusOK)
	w.Write([]byte("Transfer successful"))
}

func (s *Server) sendToken(to common.Address, amount *big.Int) error {
	// Load private key
	privateKey, err := crypto.HexToECDSA(privateKeyHex[2:])
	if err != nil {
		return fmt.Errorf("failed to load private key: %v", err)
	}

	// Get chain ID
	chainID, err := s.client.NetworkID(context.Background())
	if err != nil {
		return fmt.Errorf("failed to fetch network ID: %v", err)
	}

	auth, err := bind.NewKeyedTransactorWithChainID(privateKey, chainID)
	if err != nil {
		return fmt.Errorf("failed to create transactor: %v", err)
	}

	// Load the contract
	contract, err := dusd.NewMain(common.HexToAddress(dusdContractAddress), s.client)
	if err != nil {
		return fmt.Errorf("failed to load token contract: %v", err)
	}

	tx, err := contract.Transfer(auth, to, amount)
	if err != nil {
		return fmt.Errorf("failed to send transfer transaction: %v", err)
	}

	log.Printf("Transaction sent: %s", tx.Hash().Hex())
	return nil
}
